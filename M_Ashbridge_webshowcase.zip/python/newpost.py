
postTitle=raw_input("title for the post: ")
postDesc=raw_input("description for this post: ")
postFile=raw_input("filename (should be 'webshowcase': ")
file=open("C:\inetpub\wwwroot\index.html","a")
file.write('\n')
file.write("""<p>Title: """+postTitle+"""</p>""")
file.write("""<p>Description: """+postDesc+"""</p>""")

file.write("""<a href="C:\inetpub\wwwroot\reports"> assignment folder</a>""")
file.write("""<p>    </p>""")
file.write("""<a href="C:\inetpub\wwwroot\python\newpost.py"> python script used to make this post </a>""")
file.close()
